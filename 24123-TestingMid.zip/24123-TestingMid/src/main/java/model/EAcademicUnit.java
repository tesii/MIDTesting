package model;

public enum EAcademicUnit {

	PROGRAME,
	FACULTY,
	DEPARTMENT;
}
