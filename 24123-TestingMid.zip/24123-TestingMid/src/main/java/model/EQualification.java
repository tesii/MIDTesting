package model;

public enum EQualification {
	 MASTERS,
	 PHD,
	 PROFESSOR;
	   
}
